(function() {
  $(function() {
    return alert('Pipeline Js Applied');
  });

}).call(this);
